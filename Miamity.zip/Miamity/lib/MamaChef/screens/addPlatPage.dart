import 'dart:io';
import 'dart:math';

import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:miamitymds/Widgets/MiamityAppBar.dart';
import 'package:miamitymds/Widgets/MiamityDoubleButton.dart';
import 'package:miamitymds/Widgets/MiamityFormBuilderTextField.dart';
import 'package:miamitymds/Widgets/MiamityMultiSelect.dart';
import 'package:miamitymds/Widgets/MiamityProgressIndicator.dart';
import 'package:miamitymds/Widgets/MiamityRangeDate.dart';
import 'package:miamitymds/Widgets/MiamityTextFormField.dart';
import 'package:miamitymds/Widgets/PreviewDishCard.dart';
import 'package:miamitymds/auth.dart';
import 'package:permission_handler/permission_handler.dart';

class Dish {
  DateTime dateBegin, dateEnding;
  String locally, dishTitle, description, price;
  int nbParts;

  Dish(
      {this.dateBegin,
      this.dateEnding,
      this.dishTitle,
      this.description,
      this.locally,
      this.price,
      this.nbParts});
  factory Dish.fromJson(Map<String, dynamic> json) => _formFieldFromJson(json);
}

Dish _formFieldFromJson(Map<String, dynamic> json) {
  return Dish(
      dateBegin: json['dateBegin'] as DateTime,
      dateEnding: json['dateEnding'] as DateTime,
      dishTitle: json['dishTitle'] as String,
      description: json['description'] as String,
      locally: json['locally'] as String,
      price: json['price'] as String,
      nbParts: json['nbParts'] as int);
}

class AddPlate extends StatefulWidget {
  AddPlate(
      {this.title, this.auth, this.onSignedOut, this.image, this.currentForm});
  final String title;
  final BaseAuth auth;
  final VoidCallback onSignedOut;
  final FormBuilderState currentForm;
  final File image;
  @override
  _AddPlateState createState() => _AddPlateState();
}

class _AddPlateState extends State<AddPlate> {
  final GlobalKey<FormBuilderState> formKey = GlobalKey<FormBuilderState>();
  String userId;
  String message;
  bool isSuccess;
  String imageURL;
  bool waitingForUploadImage;
  bool _isLoading = false;
  bool isAnImage = false;
  String dropdownValue = "One";
  List<String> typeList = [
    "Accompagnements",
    "Amuse bouches",
    "Pains",
    "Pâtés",
    "Pâtes alimentaires",
    "Petits-déjeuners",
    "Plat principal",
    "Poissons",
    "Salades",
    "Sandwiches",
    "Soupes",
    "Viande",
    "Desserts",
    "Fondues",
    "Accompagnements",
    "Amuse bouches",
    "Pains",
    "Pâtés",
    "Pâtes alimentaires",
    "Petits-déjeuners",
    "Plat principal",
    "Poissons",
    "Salades",
    "Sandwiches",
    "Soupes",
    "Viande",
    "Desserts",
    "Fondues",
    "Accompagnements",
    "Amuse bouches",
    "Pains",
    "Pâtés",
    "Pâtes alimentaires",
    "Petits-déjeuners",
    "Plat principal",
    "Poissons",
    "Salades",
    "Sandwiches",
    "Soupes",
    "Viande",
    "Desserts",
    "Fondues",
    "Accompagnements",
    "Amuse bouches",
    "Pains",
    "Pâtés",
    "Pâtes alimentaires",
    "Petits-déjeuners",
    "Plat principal",
    "Poissons",
    "Salades",
    "Sandwiches",
    "Soupes",
    "Viande",
    "Desserts",
    "Fondues",
    "Fritures",
    "Boissons",
  ];
  List<String> selectedTypesList;
  String name;
  String price;
  String part;
  File _image;
  var formField;
  Dish dish;

  @override
  void initState() {
    super.initState();
    // Obtain a list of the available cameras on the device.

    message = "";
    _isLoading = false;
    isSuccess = true;
    if (_image != null) {
      isAnImage = true;
    }
    widget.auth.currentUser().then((currentUserId) {
      print("Current user id from AddPlatPage $currentUserId");
      if (currentUserId == null) {
        widget.onSignedOut;
      } else {
        setState(() {
          userId = currentUserId;
        });
      }
    });
  }

  uploadImage() async {
    if (_image == null) {
      imageURL =
          "https://cdn.samsung.com/etc/designs/smg/global/imgs/support/cont/NO_IMG_600x600.png";
      return;
    } else {
      setState(() {
        waitingForUploadImage = true;
      });
      final StorageReference firebaseStorageRef = FirebaseStorage.instance
          .ref()
          .child(Random().nextInt(10000000).toString() + ".jpg");
      final StorageUploadTask task = firebaseStorageRef.putFile(_image);
      final StorageTaskSnapshot taskSnapshot = (await task.onComplete);
      imageURL = await taskSnapshot.ref.getDownloadURL();
      setState(() {
        waitingForUploadImage = false;
      });
    }
  }

  void _openFileExplorer() async {
    ///Check si les permissions ont été données. Sinon les demande.
    PermissionStatus permissionCamera =
        await PermissionHandler().checkPermissionStatus(PermissionGroup.camera);
    PermissionStatus permissionPhoto =
        await PermissionHandler().checkPermissionStatus(PermissionGroup.photos);
    if (permissionCamera.value.toString() ==
            PermissionStatus.granted.toString() &&
        permissionPhoto.value.toString() ==
            PermissionStatus.granted.toString()) {
      print("permission already granted");
    } else {
      await PermissionHandler()
          .requestPermissions([PermissionGroup.camera, PermissionGroup.photos]);
    }
  }

  _submit() async {
    setState(() {
      _isLoading = true;
    });
    if (formKey.currentState.saveAndValidate()) {
      if (_image != null) {
        await uploadImage();
      }
      formField = formKey.currentState.value;
      dish = Dish.fromJson(formField);
      Firestore.instance
          .collection('dish')
          .add({
            "user_id": userId,
            "photo": imageURL,
            "dish_title": dish.dishTitle,
            "description": dish.description,
            "price": dish.price,
            "nb_parts": dish.nbParts,
            "dateBegin": dish.dateBegin,
            "dateEnding": dish.dateEnding,
            "locally": dish.locally,
            "types": selectedTypesList
          })
          .then((result) => {print('C\'est fait')})
          .catchError((err) => err);
      setState(() {
        isSuccess = true;
        message = "Plat ajouté avec succès";
      });
    } else {
      setState(() {
        isSuccess = false;
        message = "Veuillez renseigner les champs du formulaire.";
      });
    }
    setState(() {
      _isLoading = false;
    });
  }

  _showTypePlatDialog() {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          //Here we will build the content of the dialog
          return AlertDialog(
            title: Text("Type(s) du plat"),
            content: Container(
              width: double.maxFinite,
              child: ListView(
                children: <Widget>[
                  MiamityMultiSelect(
                    typeList,
                    onSelectionChanged: (selectedList) {
                      setState(() {
                        selectedTypesList = selectedList;
                      });
                    },
                  ),
                ],
              ),
            ),
            actions: <Widget>[
              FlatButton(
                child: Text("OK"),
                onPressed: () => Navigator.of(context).pop(),
              )
            ],
          );
        });
  }

  _buildSelectedTypesList() {
    List<Widget> choices = List();
    if (selectedTypesList != null) {
      selectedTypesList.forEach((item) {
        choices.add(Container(
          padding: const EdgeInsets.symmetric(horizontal: 4.0),
          child: Chip(
            label: Text(item),
          ),
        ));
      });
    }
    return choices;
  }

  _ApercuDuPlat() {
    if (formKey.currentState != null) {
      formKey.currentState.save();
      setState(() {
        formField = formKey.currentState.value;
        dish = Dish.fromJson(formField);
        name = dish.dishTitle;
        part = dish.nbParts.toString();
        price = dish.price.toString();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Ajouter un plat"),
        centerTitle: true,
      ),
      body: PageView(
        children: <Widget>[
          Stack(
            children: <Widget>[
              Opacity(
                opacity: _isLoading ? 0.7 : 1.0,
                child: ListView(
                  children: <Widget>[
                    FormBuilder(
                        onChanged: _ApercuDuPlat(),
                        key: formKey,
                        initialValue: widget.currentForm != null
                            ? widget.currentForm.value
                            : {
                                'dateBegin': DateTime.now(),
                                'dateEnding': DateTime.now(),
                                'locally': null,
                                'nbParts': 1,
                                'dishTitle': null,
                                'description': null,
                                'price': null
                              },
                        autovalidate: true,
                        child: Column(
                          children: <Widget>[
                            MiamityFormBuilderTextField(
                              icon: Icons.person,
                              attribute: 'dishTitle',
                              label: 'Intitulé du plat',
                              validators: [
                                FormBuilderValidators.required(
                                    errorText: 'Le champ est requis'),
                                FormBuilderValidators.max(70)
                              ],
                            ),
                            MiamityFormBuilderTextField(
                              icon: Icons.person,
                              attribute: 'description',
                              label: 'Description de votre plat',
                              validators: [
                                FormBuilderValidators.required(
                                    errorText: 'Le champ est requis'),
                                FormBuilderValidators.max(300)
                              ],
                            ),
                            Padding(
                                padding: EdgeInsets.symmetric(horizontal: 6.0),
                                child: FormBuilderStepper(
                                  initialValue: 1,
                                  step: 1,
                                  attribute: 'nbParts',
                                  decoration: InputDecoration(
                                    alignLabelWithHint: true,
                                    labelText: 'Nombres de parts',
                                    contentPadding: EdgeInsets.all(15),
                                    prefixIcon: Icon(Icons.pie_chart),
                                    border: new OutlineInputBorder(
                                        borderSide: new BorderSide(),
                                        borderRadius: new BorderRadius.all(
                                            Radius.circular(50))),
                                  ),
                                  validators: [
                                    FormBuilderValidators.required(),
                                  ],
                                )),
                            MiamityFormBuilderTextField(
                              attribute: 'price',
                              label: 'Prix par part',
                              keyboardType: TextInputType.number,
                              icon: Icons.euro_symbol,
                              validators: [
                                FormBuilderValidators.required(
                                    errorText: 'Le champs est requis'),
                                FormBuilderValidators.numeric(
                                    errorText:
                                        "La valeur ne doit pas comprendre de lettres")
                              ],
                            ),
                            Text(
                              "Période de mise à disposition de votre plat",
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            MiamityRangeDate(
                                attribute1: "dateBegin",
                                label1: "Date de début",
                                attribute2: "dateEnding",
                                label2: "Date de fin"),
                            Padding(
                                padding: EdgeInsets.all(6.0),
                                child: FormBuilderDropdown(
                                  attribute: 'locally',
                                  decoration: InputDecoration(
                                    labelText: 'Sur place ou à emporter ?',
                                    contentPadding: EdgeInsets.all(18),
                                    border: new OutlineInputBorder(
                                        borderSide: new BorderSide(),
                                        borderRadius: new BorderRadius.all(
                                            Radius.circular(50))),
                                  ),
                                  items: ['Sur place', 'A emporter']
                                      .map((locally) => DropdownMenuItem(
                                          value: locally,
                                          child: Text("$locally")))
                                      .toList(),
                                  validators: [
                                    FormBuilderValidators.required(
                                        errorText: 'Le champs est requis')
                                  ],
                                )),
                            selectedTypesList == null
                                ? MiamityTextFormField(
                                    label: "Types de plat",
                                    onTap: () => _showTypePlatDialog(),
                                    readOnly: true,
                                  )
                                : Text("Types de plat:"),
                            FlatButton(
                                onPressed: () => _showTypePlatDialog(),
                                child: Wrap(
                                  children: _buildSelectedTypesList(),
                                )),
                            Padding(
                              padding: EdgeInsets.symmetric(vertical: 4),
                            ),
                          ],
                        )),
                    Container(
                        child: Row(
                      children: <Widget>[
                        MiamityDoubleButton(
                          btnColor1: Colors.blue,
                          title1: "JE CHOISIS UNE PHOTO",
                          onPressed1: () async {
                            _selectImageFrom(isCamera: false);
                          },
                          title2: "JE PREND UNE PHOTO",
                          onPressed2: () {
                            _selectImageFrom(isCamera: true);
                          },
                        )
                      ],
                    )),
                    Center(
                        child: PreviewDishCard(
                            image: _image,
                            name: name,
                            nombrePart: part,
                            price: price)),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child: MaterialButton(
                            color: Colors.green,
                            onPressed: _submit,
                            child: Text('Mettre en ligne'),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child: MaterialButton(
                            color: Colors.grey,
                            onPressed: () => {
                              formKey.currentState.reset(),
                            },
                            child: Text('Reset'),
                          ),
                        ),
                      ],
                    ),
                    Wrap(
                      children: <Widget>[
                        isSuccess
                            ? Text(message,
                                style: TextStyle(
                                    color: Colors.green,
                                    fontWeight: FontWeight.bold))
                            : Text(message,
                                style: TextStyle(
                                    color: Colors.red,
                                    fontWeight: FontWeight.bold))
                      ],
                    ),
                  ],
                ),
              ),
              Opacity(
                  opacity: _isLoading ? 1.0 : 0.0,
                  child: MiamityProgressIndicator())
            ],
          ),
        ],
      ),
      endDrawer: MiamityAppBar(
        auth: widget.auth,
        onSignedOut: widget.onSignedOut,
      ),
    );
  }

  Future _selectImageFrom({bool isCamera}) async {
    var image = await ImagePicker.pickImage(
        source: isCamera ? ImageSource.camera : ImageSource.gallery);

    File croppedImage = await ImageCropper.cropImage(
      sourcePath: image.path,
      ratioX: 1.3,
      ratioY: 1.0,
      maxWidth: 400,
      maxHeight: 400,
    );
    setState(() {
      _image = croppedImage;
    });
  }
}
